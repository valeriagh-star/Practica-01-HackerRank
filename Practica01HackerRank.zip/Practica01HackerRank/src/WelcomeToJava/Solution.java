package WelcomeToJava;

public class Solution {
	 public static void main(String[] args) {
	        System.out.println("Hello, World.");
	        System.out.println("Hello, Java.");
	    }
}
