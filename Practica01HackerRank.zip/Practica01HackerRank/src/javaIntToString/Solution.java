package javaIntToString;
import java.security.Permission;
import java.util.Scanner;

public class Solution {
		 public static void main(String[] args) {

		  DoNotTerminate.forbidExit();

		  try {
		   Scanner in = new Scanner(System.in);
		   int n = in .nextInt();
		   in.close();
		   String s = Integer.toString(n);
		   if (n == Integer.parseInt(s)) {
			    System.out.println("Good job");
			   } else {
			    System.out.println("Wrong answer.");
			   }
			  } catch (DoNotTerminate.ExitTrappedException e) {
			   System.out.println("Unsuccessful Termination!!");
			  }
			 }
			}

			//The following class will prevent you from terminating the code using exit(0)!
			class DoNotTerminate {

			 @SuppressWarnings("removal")
			private static final class SecurityManagerExtension extends SecurityManager {
					@Override
					   public void checkPermission(Permission permission) {
					    if (permission.getName().contains("exitVM")) {
					     throw new ExitTrappedException();
					    }
					   }
				}

			 public static class ExitTrappedException extends SecurityException {

			  private static final long serialVersionUID = 1;
			 }

			 @SuppressWarnings("removal")
			public static void forbidExit() {
			  final SecurityManager securityManager = new SecurityManagerExtension();
			  System.setSecurityManager(securityManager);

			 }
			}
